# GKS-Block – IP-Symcon Modul

Bildet einen GKS-Block (3 Magnetventile V1 = Nebenventil, V2 = Hauptventil,
V3 = Bypassventil) inklusive der automatischen Freigabe-Prüfsequenz und
manuellem Handbetrieb je Ventil nach – funktional 1:1 zur GKS-Block-Logik im
Burghausen-Dashboard (`burghausen_19_de_en_3.html`).

**Eine Instanz = ein GKS-Block = ein Gas.** Für die sechs Gase aus dem
Dashboard (H2_40, H2_50, AR, HE, N2O2, N2) legst du sechs Instanzen an.

---

## 1. Installation

### Variante A – als Git-Modul (empfohlen)
1. Diesen Ordner (inkl. `library.json` und Unterordner `GKSBlock/`) in ein
   eigenes Git-Repository legen (z. B. auf einem internen GitLab/Gitea oder
   auch nur lokal als Ordner).
2. In IP-Symcon: **Module Store → Symbol „Eigene Module hinzufügen" (＋) →
   Git-URL eintragen.**
3. Danach steht „GKS-Block" unter **Instanz hinzufügen** zur Verfügung.

### Variante B – lokal ohne Git
1. Den Ordner `GKSBlock` direkt nach `/var/lib/symcon/modules/` kopieren
   (Pfad ggf. je nach Installation anpassen).
2. In der Konsole: `IPS_CreateModule('GKSBlock')` bzw. über
   **Kern-Instanzen → Modul-Steuerung → Module neu einlesen.**

---

## 2. Instanz anlegen

Für jedes Gas eine Instanz **GKS-Block** anlegen und konfigurieren:

| Feld | Beispiel (H2_40) |
|---|---|
| Gas-Symbol | `H2_40` |
| Gas-Klartext (DE) | `Wasserstoff 4.0` |
| Gas-Klartext (EN) | `Hydrogen 4.0` |

**Netzdruck:** Optional eine echte Sensor-Variable verknüpfen (z. B. aus
einem Modbus-/CATAN-Modul). Ohne Verknüpfung simuliert das Modul den
Füllvorgang selbst (Füllrate konfigurierbar) – praktisch zum Testen ohne
angeschlossene Hardware, genau wie die Demo-Simulation im Dashboard.

**Ausgänge (optional):** V1/V2/V3 können mit realen Ausgangsvariablen
(z. B. Relais eines Phoenix Contact CATAN C1) verknüpft werden. Das Modul
schaltet diese dann per `RequestAction` automatisch mit, sobald es selbst
ein Ventil öffnet/schließt.

**Prüfsequenz-Parameter:** Entsprechen 1:1 den Werten aus dem Dashboard
(`GKS_FILL1_TARGET`, `GKS_TEST1_DURATION`, `GKS_FILL2_TARGET`,
`GKS_TEST2_DURATION`, `GKS_FILL_RATE`).

---

## 3. Angelegte Statusvariablen je Instanz

| Ident | Typ | Bedeutung |
|---|---|---|
| `V1` / `V2` / `V3` | Bool | Ventilstellung (zu/auf) – aktionsfähig |
| `V1Mode` / `V2Mode` / `V3Mode` | Integer | Betriebsart je Ventil: 0 = Automatik, 1 = Hand – aktionsfähig |
| `NetworkPressure` | Float | Aktueller Netzdruck (bar) |
| `Phase` | String | `idle`, `fill1`, `test1`, `fill2`, `test2`, `released`, `locked` |
| `RemainingSeconds` | Integer | Restlaufzeit der laufenden Prüfzeit |
| `TotalRuntime` | Integer | Gesamtlaufzeit der letzten Freigabe-Sequenz |
| `ReleaseHint` | String | Hinweistext, falls Freigabe wegen Handbetrieb blockiert ist |
| `BlockStatus` | Integer | Sammelstatus: 0 = OK (grün), 1 = Störung (gelb), 2 = Alarm (rot) |
| `Freigeben` | Bool (Taster) | Löst `GKSB_Freigeben($id)` aus |
| `Sperren` | Bool (Taster) | Löst `GKSB_Sperren($id)` aus |

Die drei Ventile lassen sich nur schalten, solange sich das jeweilige
Ventil im **Handbetrieb** befindet – identisch zur Regel im Dashboard.
Ein Zurückschalten auf Automatik setzt das Ventil (sofern gerade keine
Sequenz läuft) automatisch in den Bereitschaftszustand zurück
(V1 zu, V2/V3 auf).

„Sperre GKS" schließt sofort alle drei Ventile und setzt alle
Betriebsarten auf Automatik zurück. „Freigabe GKS" funktioniert danach
ganz normal wieder und hebt die Sperre damit auf.

---

## 4. Visualisierung

Jede Instanz liefert über `GetVisualizationTile()` eine eigene,
live aktualisierte Kachel (Diagramm, Phase, Timer, Freigabe-/Sperre-Buttons)
im WebFront – gestalterisch angelehnt an das GKS-Block-Popup im
Burghausen-Dashboard. Die Aktualisierung läuft bewusst über denselben
`/api/`-JSON-RPC-Endpunkt (`IPS_GetValue` / `RequestAction`), den auch das
bestehende Dashboard schon verwendet – dieselbe, nachweislich funktionierende
Technik statt einer möglicherweise versionsabhängigen internen
Visualisierungs-API.

Das Schalten der Ventile (Handbetrieb ein/aus, Auf/Zu) erfolgt bewusst
**nicht** direkt in der Kachel, sondern über die normalen Statusvariablen
der Instanz (Variablenliste bzw. eigenes WebFront-Dashboard-Widget) – dort
stehen `V1`/`V2`/`V3` als Schalter und `V1Mode`/`V2Mode`/`V3Mode` als
Auswahl (Automatik/Hand) ohnehin bereits zur Verfügung.

---

## 5. Verhältnis zum bestehenden HTML-Dashboard

Das Modul ersetzt **nicht zwingend** das bestehende
`burghausen_19_de_en_3.html`-Dashboard, sondern bildet dieselbe Logik jetzt
serverseitig in IP-Symcon ab. Zwei sinnvolle Kombinationen:

- **Nur Modul + Standard-WebFront:** Variablen/Kacheln direkt verwenden,
  das HTML-Dashboard entfällt.
- **Modul + bestehendes HTML-Dashboard:** Die im Dashboard vorbereiteten
  Integrationspunkte (`raum1108VariableMap`, `ipsGetValue`/`ipsSetValue`,
  GKS-Block-Ventile) einfach auf die von diesem Modul angelegten
  Variablen-IDs zeigen lassen – das Dashboard liest/schreibt dann live die
  echten Werte dieses Moduls, die komplette Prüfsequenz-Logik läuft aber
  jetzt zuverlässig auf dem Symcon-Server statt nur im Browser.

---

## 6. Dateien in diesem Repository

```
library.json              Repository-Metadaten (für Modul-Store)
GKSBlock/
  module.json              Modul-Metadaten (GUID, Typ, Prefix "GKSB")
  module.php                Zustandsautomat, Aktionen, Visualisierung
  form.json                  Konfigurationsformular der Instanz
  locale.json                 Englische Übersetzung der Formulartexte
```
